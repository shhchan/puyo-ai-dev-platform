"""Rerun the unsaved fixed samples sequentially with explicit JSON sentinels."""

import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
for repeat in (1, 2, 3):
    for condition, checkout in (("baseline", WORK / "baseline"), ("candidate", WORK / "puyo-242")):
        subprocess.run([
            str(checkout / ".venv/bin/python"), str(ROOT / "fixed_capture.py"),
            str(ROOT), condition, str(repeat),
        ], cwd=checkout, check=True,
           env={**os.environ, "PYTHONPATH": f"{checkout}:{WORK / 'puyo-242/eval'}"})
