"""Serialize ranking sentinels after timing; retain strict JSON and source build."""

import argparse
import hashlib
import math
from pathlib import Path

import puyo242_known_prefix_trial as trial


def encode_sentinels(value):
    if isinstance(value, dict):
        return {k: encode_sentinels(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode_sentinels(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        if math.isnan(value):
            raise ValueError("NaN is not a valid ranking sentinel")
        return "-Infinity" if value < 0 else "Infinity"
    return value


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("condition", choices=trial.CONDITIONS)
    parser.add_argument("repeat", type=int)
    args = parser.parse_args()
    original = trial.baseline._write_json

    def write_fixed(path, payload):
        assert Path(path).name.startswith("fixed-")
        payload = encode_sentinels(payload)
        payload["capture_adapter"] = {
            "file": str(Path(__file__).resolve()),
            "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "change": "post-timing JSON encoding of +/-Infinity ranking sentinels; NaN rejected",
        }
        original(path, payload)

    trial.baseline._write_json = write_fixed
    trial.fixed(args.root, args.condition, args.repeat)
