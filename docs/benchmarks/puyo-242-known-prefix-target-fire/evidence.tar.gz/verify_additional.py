"""Post-measurement checks; deliberately never run during timing."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
inputs = json.loads((ROOT / "fixed-inputs.json").read_text())
sources = {(c["seed"], c["turn"]): bytes.fromhex(c["request_hex"]) for c in inputs["cases"]}
groups = {}
for condition in ("baseline", "candidate"):
    groups[condition] = {}
    for path in sorted((ROOT / condition).glob("fixed-*.json")):
        for sample in json.loads(path.read_text())["samples"]:
            key = sample["seed"], sample["turn"]
            migration = sample["request_migration"]
            source = sources[key]
            assert migration["source_sha256"] == hashlib.sha256(source).hexdigest()
            target = "puyo.expected_chain_ranking." + ("v2" if condition == "baseline" else "v3")
            effective = source.replace(b"puyo.expected_chain_ranking.v2", target.encode())
            assert migration["effective_sha256"] == hashlib.sha256(effective).hexdigest()
            assert migration["only_ranking_identity_changed"]
            assert migration["root_known_pairs_search_evaluator_execution_bytes_unchanged"]
            assert migration["request_id_unchanged"]
            assert sample["native_ranking"] == [r["root_action"] for r in sample["roots"]]
            for root in sample["roots"]:
                fire = root["best_fire"]
                if fire is not None and fire["terminal"]:
                    assert sample["representatives"][str(root["root_action"])]["path"] == fire["path"]
            groups[condition].setdefault(key, []).append(sample)

result = {"fixed_comparisons": [], "request_identity_migration_checked": True,
          "all_fixed_terminal_representative_paths_match": True}
for key in sources:
    old, new = groups["baseline"][key], groups["candidate"][key]
    assert len(old) == len(new) == 6
    for samples in (old, new):
        assert all(s["roots"] == samples[0]["roots"] for s in samples)
        assert all(s["representatives"] == samples[0]["representatives"] for s in samples)
    a, b = old[0], new[0]
    assert a["counters"] == b["counters"]
    previous = {r["root_action"]: r for r in a["roots"]}
    for root in b["roots"]:
        before = previous[root["root_action"]]
        assert root["fire_class"] == before["fire_class"]
        assert root["fire_class_support"] == before["fire_class_support"]
        for left, right in zip(before["scenario_values"], root["scenario_values"], strict=True):
            # Official maxima, counts, coverage, survivor state and all other
            # recorded search facts are unchanged. Only retained target changes.
            assert {k: v for k, v in left.items() if k != "selected_fire"} == {
                k: v for k, v in right.items() if k != "selected_fire"}
    result["fixed_comparisons"].append({
        "seed": key[0], "turn_1based": key[1] + 1,
        "counters_equal": True, "scenario_search_facts_equal_except_selected_fire": True,
        "baseline_action": a["native_ranking"][0], "candidate_action": b["native_ranking"][0],
        "baseline_fire": a["roots"][0]["best_fire"], "candidate_fire": b["roots"][0]["best_fire"],
    })
(ROOT / "additional-verification.json").write_text(json.dumps(result, indent=2) + "\n")
print("7 fixed boards / 84 samples: input migration, counters and terminal representatives verified")
