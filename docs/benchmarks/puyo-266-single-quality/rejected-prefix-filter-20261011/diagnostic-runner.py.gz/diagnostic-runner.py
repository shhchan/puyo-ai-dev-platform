"""Isolated counterfactual; product source and acceptance rules stay unchanged."""
import dataclasses
import gzip
import hashlib
import json
import pathlib
import subprocess
import sys
from types import SimpleNamespace
from agents import deep_chain_builder as d
from agents.long_horizon_search import aggregate_expected_chain_evidence, apply_weak_scenario_support_guard, LongHorizonSearchConfig
from agents.nextgen_survival import _ControlProof, _ProofCutoff
from agents.compact_search import transition
from eval import nextgen_single_quality_gate as g

OUT=pathlib.Path('runs/puyo-266-prefix-filter-diagnostic-v1')
ORIGINAL=d.SelectPlacementStep.run
TRACE=[]
class Proof(_ControlProof):
 def __init__(self,limit):super().__init__(None,0,reuse_control_graph=True);self.nodes=0;self.limit=limit
 def charge(self,kind):
  if self.nodes>=self.limit:raise _ProofCutoff
  self.nodes+=1;self.charged[kind]+=1

def filtered_select(self,context):
 payload=context.require(d.SCENARIO_SEARCH_RESULTS_ARTIFACT);result=payload['result'];state=payload['root_state'];visible=context.require(d.RUNTIME_INPUT_ARTIFACT)
 pairs=result.scenario_sequences[0].known_pairs
 assert len(pairs)==3
 proof=Proof(int(context.profile.max_expanded_nodes)-result.counters.expanded_nodes)
 cache={};modified=[];removed=[]
 values=context.require(d.AGGREGATED_ROOT_SCORES_ARTIFACT)
 for value in values:
  root=value['root_action']
  if not visible.action_mask[root]:continue
  evidence=value['evidence'];kept=[]
  for v in evidence.scenario_values:
   f=v.selected_fire
   if f is None:kept.append(v);continue
   current=state;failure=None
   for depth,action in enumerate(f.path[:4]):
    reachable=visible.action_mask[action] if depth==0 else proof.reachable(current,pairs[min(depth,2)],action)
    if not reachable:failure=(depth+1,action);break
    if depth==3:break
    key=(current.to_bytes(),depth,action)
    if key not in cache:proof.charge('placement');cache[key]=transition(current,pairs[depth],action)
    t=cache[key]
    if not t.valid or t.game_over:failure=(depth+1,action);break
    current=t.state
   if failure is None:kept.append(v)
   else:
    removed.append({'root':root,'scenario':v.scenario_id,'class':f.fire_class,'failure':failure})
    kept.append(dataclasses.replace(v,best_fire=None,selected_fire=None,selected_fire_class='unavailable',survivor_evaluator_score=None,max_chain_count=0,max_chain_score=0))
  modified.append(aggregate_expected_chain_evidence(root,kept,requested_scenarios=6))
 cfg=LongHorizonSearchConfig(depth=16,width=250,scenarios=6,minimum_chain_count=10,max_expanded_nodes=600000)
 modified=apply_weak_scenario_support_guard(modified,config=cfg,fatal_score=-1e12)
 selected=max(modified,key=lambda e:e.ranking_key);native_selected=next(v['root_action'] for v in sorted(values,key=lambda v:v['ranking_key'],reverse=True) if visible.action_mask[v['root_action']])
 replacement=[];originals={v['root_action']:v for v in values}
 for e in modified:
  value={**originals[e.root_action],'ranking_key':e.ranking_key,'score_breakdown':e.value_breakdown(),'evidence':e}
  if e.root_action==selected.root_action:
   original=e.to_dict()==originals[e.root_action]['evidence'].to_dict()
   if not original:
    f=e.best_fire;node=SimpleNamespace(path=f.path if f is not None else (e.root_action,),scenario_id=f.scenario_id if f is not None else result.scenario_sequences[0].scenario_id)
    shadow=dataclasses.replace(result,representatives={e.root_action:node})
    value['representative']=d._representative_payload(shadow,e.root_action,state)
    value['representative']['trajectory_source']='diagnostic_filtered_fire' if f is not None else 'diagnostic_root_only_missing_quiet_path'
  replacement.append(value)
 assert result.counters.expanded_nodes+proof.nodes<=600000
 TRACE.append({'tick':visible.step_count,'native_root':native_selected,'filtered_root':selected.root_action,'removed':removed,'additional_nodes':proof.nodes,'charged':proof.charged,'native_expanded':result.counters.expanded_nodes,'total_nodes':result.counters.expanded_nodes+proof.nodes,'quiet_paths_unverified':True,'unrecorded_alternatives_unknown':True})
 patched=dataclasses.replace(context,artifacts={**context.artifacts,d.AGGREGATED_ROOT_SCORES_ARTIFACT:tuple(replacement)})
 return ORIGINAL(self,patched)

def write_progress(path,raw):
 raw['diagnostic_prefix_filter']=TRACE
 stage=path.with_suffix('.tmp');stage.write_bytes(gzip.compress(json.dumps(raw).encode(),mtime=0));stage.replace(path)

if len(sys.argv)==1:
 g.require_clean();manifest={'purpose':'nonformal counterfactual public-prefix evidence filter; no product patch','source':g.current_source(),'build':g.build_identity(),'config':g.configuration('/home/sion2000114/.cache/puyo-s15/haipuyo.txt'),'patterns':[4519,2259],'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'limitations':['missing alternate trajectories unknown','quiet paths unverified','no acceptance declaration']};manifest['sha256']=g.digest(manifest);g.write_new(OUT/'manifest.json',manifest)
 for pattern in manifest['patterns']:
  done=subprocess.run([sys.executable,__file__,str(pattern)],check=False);print('WORKER_EXIT',pattern,done.returncode,flush=True)
else:
 pattern=int(sys.argv[1]);m=g.read(OUT/'manifest.json');g.require_clean();assert g.current_source()==m['source'];assert g.build_identity()==m['build'];d.SelectPlacementStep.run=filtered_select
 progress=OUT/f'pattern-{pattern}.progress.json.gz'
 try:
  raw=g.measure(g.new_match(m['config'],pattern),g.make_policy('deep_chain_builder'),'deep_chain_builder',progress=lambda value:write_progress(progress,value))
  raw.update(schema=g.SCHEMA,pattern_id=pattern,repeat=1,manifest_sha256=m['sha256'],diagnostic_prefix_filter=TRACE,diagnostic_only=True)
  g.complete_evidence(raw,g.new_match(m['config'],pattern));assert g.current_source()==m['source'];g.require_clean();assert g.build_identity()==m['build'];g.write_new(OUT/f'pattern-{pattern}.json.gz',raw)
  row=g.validated_row(raw,m);row['changed_roots']=[r for r in TRACE if r['native_root']!=r['filtered_root']];row.pop('decision_seconds',None);g.write_new(OUT/f'pattern-{pattern}.summary.json',row);print(json.dumps(row),flush=True)
 except Exception as error:
  g.write_new(OUT/f'pattern-{pattern}.failure.json',{'error':str(error),'type':type(error).__name__,'trace':TRACE});raise
